from django.db import IntegrityError, transaction
from django.test import TestCase

from localizacao.models import Localizacao
from usuario.models import Usuario
from veiculo.models import Veiculo
from .models import Corrida
from .services import AlocacaoVeiculo


class AlocacaoVeiculoTests(TestCase):
	def setUp(self):
		self.usuario = Usuario.objects.create(nome='Cliente')
		self.veiculo = Veiculo.objects.create(modelo='Patinete', placa='ABC1234')
		self.localizacao = Localizacao.objects.create(
			veiculo=self.veiculo,
			latitude=-23.550520,
			longitude=-46.633308,
		)

	def criar_corrida_ativa(self):
		return Corrida.objects.create(
			usuario=self.usuario,
			veiculo=self.veiculo,
			localizacao_inicio=self.localizacao,
		)

	def test_alocador_e_singleton(self):
		self.assertIs(AlocacaoVeiculo(), AlocacaoVeiculo())

	def test_apenas_uma_corrida_ativa_por_veiculo(self):
		corrida = self.criar_corrida_ativa()
		AlocacaoVeiculo().iniciar(corrida)

		with self.assertRaises(IntegrityError):
			with transaction.atomic():
				self.criar_corrida_ativa()

		self.veiculo.refresh_from_db()
		self.assertEqual(self.veiculo.status, 'em_uso')
