from django.db import IntegrityError
from rest_framework import serializers
from .models import Corrida

class CorridaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Corrida
        fields = '__all__'

    def validate(self, data):
        usuario = data.get('usuario')
        if usuario and not usuario.assinaturas.filter(ativa=True).exists():
            raise serializers.ValidationError("Usuário não possui assinatura ativa.")

        veiculo = data.get('veiculo')
        if veiculo and (
            veiculo.status != 'disponivel'
            or Corrida.objects.filter(veiculo=veiculo, status='ativa').exists()
        ):
            raise serializers.ValidationError(
                {'veiculo': 'Veículo não está disponível para alocação.'}
            )
        return data

    def create(self, validated_data):
        try:
            return super().create(validated_data)
        except IntegrityError as exc:
            raise serializers.ValidationError(
                {'veiculo': 'Veículo já foi alocado por outro cliente.'}
            ) from exc