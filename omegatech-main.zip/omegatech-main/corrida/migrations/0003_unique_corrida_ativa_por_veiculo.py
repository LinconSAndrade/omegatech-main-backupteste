from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('corrida', '0002_initial'),
    ]

    operations = [
        migrations.AddConstraint(
            model_name='corrida',
            constraint=models.UniqueConstraint(
                condition=models.Q(status='ativa'),
                fields=('veiculo',),
                name='unique_corrida_ativa_por_veiculo',
            ),
        ),
    ]