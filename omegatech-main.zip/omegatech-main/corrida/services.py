from django.db import transaction

from veiculo.models import Veiculo


class AlocacaoIndisponivelError(Exception):
    pass


class AlocacaoVeiculo:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @transaction.atomic
    def iniciar(self, corrida):
        veiculo = Veiculo.objects.select_for_update().get(pk=corrida.veiculo_id)

        if veiculo.status != 'disponivel':
            raise AlocacaoIndisponivelError(
                'Veículo não está disponível para alocação.'
            )

        veiculo.status = 'em_uso'
        veiculo.save(update_fields=['status'])
        return veiculo